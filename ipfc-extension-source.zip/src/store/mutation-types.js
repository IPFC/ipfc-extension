export const updateJwt = 'updateJwt';
export const deleteJwt = 'deleteJwt';
export const updatePinataKeys = 'updatePinataKeys';
// export const updateRunInNewWindow = 'updateRunInNewWindow';
export const updateNewCardData = 'updateNewCardData';
export const updateUserCollection = 'updateUserCollection';
