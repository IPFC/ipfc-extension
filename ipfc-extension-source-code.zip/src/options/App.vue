<template>
  <div>
    <p>Hello world!</p>
  </div>
</template>

<script>
export default {
  name: 'App',
};
</script>

<style scoped>
p {
  font-size: 20px;
}
</style>
